//
//  BadgeBackground.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/07.
//

import SwiftUI

struct BadgeBackground: View {
    var body: some View {
        
        GeometryReader { geometry in
          ZStack {
            ForEach(0..<3) { i in
              Rectangle()
                .fill(
                  LinearGradient(
                    gradient: .init(colors: [Color.green, Color.blue]),
                    startPoint: .bottomLeading,
                    endPoint: .topTrailing)
                  )
             
              .frame(width: geometry.size.width * 0.7,
                     height: geometry.size.width * 0.7)
              .rotationEffect(.degrees(Double(i) * 60.0))
            }
           
            
          }
        }
    }

}

struct FirstVisitAward_Previews: PreviewProvider {
  static var previews: some View {
    Group {
        
        BadgeBackground()
            .environment(\.colorScheme, .dark)
                .frame(width: 200, height: 200)
      
      }
    }
  }


