//
//  List.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/07.
//

import SwiftUI

struct HistoryList: View {
    @EnvironmentObject var modelData: ModelData
    @State private var showFavoritesOnly = false
    @State private var notFavorites = false
    
    var filteredLandmarks: [Landmark] {
        modelData.historicals.filter{
            history in
            (!showFavoritesOnly || history.isFavorite)
        }
    }
    
    var filteredsLandmarks: [Landmark] {
        modelData.historicals.filter{
            history in
            (!notFavorites || history.isFavorite)
        }
    }
    
    let rows = [
        GridItem(.flexible()),GridItem(.flexible())
    ]
    
    let row = [
        GridItem(.flexible())
    ]

    var body: some View {
        VStack {
            NavigationView{
                
                ScrollView(.vertical, showsIndicators: true){
                    HStack {
                        Text("Favorites")
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .multilineTextAlignment(.leading)
                            Spacer()
                            
                        Button(action: {
                            withAnimation{
                            self.showFavoritesOnly.toggle()
                            }
                        }) {
                            Image(systemName: "chevron.right")
                                    .rotationEffect(.degrees(showFavoritesOnly ? 90 : 0))
                                .foregroundColor(.black)
                        }
                    }.padding(.horizontal, 10)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        LazyHGrid(rows: showFavoritesOnly ? rows : row, alignment: .firstTextBaseline) {
                            ForEach(filteredLandmarks){
                                history in
                                NavigationLink(destination: HistoryDetail(history: history)){
                                        Row(history: history).frame(width: 200)
                                }
                            }
                        }.padding(.leading).frame(height: showFavoritesOnly ? 500 : 250)
                        
                    }.ignoresSafeArea(edges: .vertical)
            
                    Divider().padding()
                    LazyVGrid(columns: [
                        GridItem(.flexible(minimum: 100, maximum: 250),spacing: 5),
                        GridItem(.flexible(minimum: 100, maximum: 250),spacing: 15)
                    ], spacing: 10, content: {
                        ForEach(filteredsLandmarks){
                            history in
                            NavigationLink(destination: HistoryDetail(history: history)){
                                VStack {
                                    Row(history: history).frame(width: 200, height: 250)
                                }
                            }
                        }
                    })
            }.navigationTitle("Historical Landmarks")
        }
    }
  }
}

struct List_Previews: PreviewProvider {    
    static var previews: some View {
        HistoryList()
            .environmentObject(ModelData())
    }
}
