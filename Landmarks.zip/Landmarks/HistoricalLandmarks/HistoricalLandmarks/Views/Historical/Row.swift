//
//  Row.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/07.
//

import SwiftUI

struct Row: View {
    var history: Landmark
     
    
    var body: some View {
        
        VStack(alignment: .center){
            
            ZStack {
                history.image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 200, height: 200, alignment: .bottom)
               
                if history.isFavorite{
                    Image(systemName: "star.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                        .padding(.top, 150)
                        .padding(.leading, 150)
                }
            }.frame(width: 200, height: 200)
            .clipShape(RoundedRectangle(cornerRadius: 40, style: .circular))
            
            HStack(alignment: .firstTextBaseline) {
                Text(history.name)
                    .font(.system(size: 18))
                    .fontWeight(.heavy)
                    .foregroundColor(Color(hue: 0.618, saturation: 0.969, brightness: 0.575))
                    .padding(.leading, 5)
                    .padding(.bottom)
            }
            
        }
        
    }
}

struct Row_Previews: PreviewProvider {
    static var historicals = ModelData().historicals
    static var previews: some View {
            Group {
                Row(history: historicals[0])
                Row(history: historicals[2])
            }
            .previewLayout(.fixed(width: 220, height: 250))
    }
}
