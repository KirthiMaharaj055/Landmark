//
//  HistoryDetail.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/07.
//

import SwiftUI

struct HistoryDetail: View {
    @EnvironmentObject var modelData: ModelData
    var history: Landmark
    
    var historyIndex: Int {
        modelData.historicals.firstIndex(where: { $0.id == history.id })!
    }
    
    var body: some View {
        ScrollView {
            MapView(coordinate: history.locationCoordinate)
                .ignoresSafeArea(edges: .top)
                .frame(height: 350)
            
            CircleImage(image: history.image)
                .offset(y: -130)
                .padding(.bottom, -130)
            
            VStack(alignment: .leading){
                HStack {
                    Text(history.name)
                        .font(.title)
                        .foregroundColor(Color.primary)
                    FavoriteButton(isSet: $modelData.historicals[historyIndex].isFavorite)
                }
                
                HStack {
                    Text(history.placeType)
                        .font(.subheadline)
                    Spacer()
                    Text(history.province)
                        .font(.subheadline)
                }
                .font(.subheadline)
                .foregroundColor(.secondary)
                Divider()

                Text("About \(history.name)")
                        .font(.title2)
                Text(history.description)
            }
            .padding()
            
        }
        .navigationTitle(history.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct HistoryDetail_Previews: PreviewProvider {
    static let modelData = ModelData()
    static var previews: some View {
        HistoryDetail(history: ModelData().historicals[2])
            .environmentObject(modelData)
    }
}
