//
//  Favorite.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/05/09.
//

import SwiftUI

struct Favorite: View {
    //
    //  List.swift
    //  HistoricalLandmarks
    //
    //  Created by IACD-Air-7 on 2021/04/07.
    //

   

        @EnvironmentObject var modelData: ModelData
        @State private var showFavoritesOnly = false
        
        var filteredLandmarks: [Landmark] {
            modelData.historicals.filter{
                history in
                (!showFavoritesOnly || history.isFavorite)
            }
        }
        
        let rows = [
            GridItem(.flexible()),
            GridItem(.flexible())
        ]
        
        let row = [
            GridItem(.flexible()),
            GridItem(.flexible())
        ]

        var body: some View {
            VStack {
                NavigationView {
                    ScrollView{
                        HStack {
                            Text("Favorites")
                                .font(.subheadline)
                                .fontWeight(.bold)
                                .multilineTextAlignment(.leading)
                                .padding(.horizontal, 70)
                                
                            Button(action: {
                                self.showFavoritesOnly.toggle()
                            }) {
                                Image(systemName: "chevron.right")
                                        .rotationEffect(.degrees(showFavoritesOnly ? 90 : 0))
                                    .foregroundColor(.black)
                            }
                        }.padding(.horizontal)
                        ScrollView {
                            LazyVGrid(columns: showFavoritesOnly ? rows : row, spacing:12, content: {
                                ForEach(filteredLandmarks){
                                    history in
                                    NavigationLink(destination: HistoryDetail(history: history)){
                                        VStack {
                                            Row(history: history)
                                        }
                                    }
                            }
             
                        }).padding(.leading).frame(height: showFavoritesOnly ? 500 : 220)
                    }.ignoresSafeArea(edges: .vertical)
                    Divider().padding(.all)
                        LazyVGrid(columns: [
                            GridItem(.flexible(minimum: 100, maximum: 200),spacing: 30),
                            GridItem(.flexible(minimum: 100, maximum: 200),spacing: 30)
                        ], spacing:12, content: {
                            ForEach(filteredLandmarks){
                                history in
                                NavigationLink(destination: HistoryDetail(history: history)){
                                    VStack {
                                        Row(history: history)
                                    }
                                }
                        }
         
                    })
                        
                }.navigationTitle("Historical Landmarks")
                }
        }
      }
    }


struct Favorite_Previews: PreviewProvider {
    static var previews: some View {
        Favorite()
    }
}
