//
//  CategoryItem.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/12.
//

import SwiftUI

struct CategoryItem: View {
    var history: Landmark
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            history.image
                .renderingMode(.original)
                .resizable()
                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                .frame(width: 155, height: 155)
                .cornerRadius(10)
            
            Text(history.name)
                .foregroundColor(.primary)
                .font(.caption)
        }
        .padding(.leading, 15)
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .circular))
    }
}


struct CategoryItem_Previews: PreviewProvider {
    static var previews: some View {
        CategoryItem(history: ModelData().historicals[0])
    }
}
