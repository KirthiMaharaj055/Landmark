//
//  CircleImage.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/06.
//

import SwiftUI

struct CircleImage: View {
    var image: Image
    var body: some View {
        image
            .clipShape(Capsule())
            .overlay(Capsule().stroke(Color.red, lineWidth: 4))
            .shadow(color: .blue, radius: 5)
            
    }
}

struct CircleImage_Previews: PreviewProvider {
    static var previews: some View {
        CircleImage(image: Image("robbenIsland"))
    }
}
