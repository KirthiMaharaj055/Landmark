//
//  Cate.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/12.
//

import SwiftUI


struct Cate: View {
    @EnvironmentObject var modelData: ModelData
    var body: some View {
        NavigationView {
            GeometryReader {
                geometry in
                ScrollView {
                    VStack {
                        modelData.features[0].image
                            .resizable()
                            .scaledToFill()
                            .frame(height: 200)
                            .clipped()
                        ForEach(modelData.categories.keys.sorted(), id: \.self){
                            key in
                            CateRow(categoryName: <#T##String#>, items: <#T##[Landmark]#>, geometry: <#T##GeometryProxy#>)
                        }
                    }
                    .padding()
                }
                .navigationTitle("Category")
                .navigationBarHidden(true)
            }
        }
    }
}
struct CategoryCard: View {
    var history: Landmark
    let geometry: GeometryProxy
   
    var body: some View {
        VStack {
            history.image
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 100, height: 100)
            Text(history.name)
                .font(.headline)
                .padding(.leading, 15)
                .padding(.top, 5)
        }
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

struct CateRow: View {
    var categoryName: String
    var items: [Landmark]
    let geometry: GeometryProxy
    var body: some View {
        
        HStack {
            Text(categoryName)
                .font(.headline)
                .padding(.leading, 15)
                .padding(.top, 5)
            ForEach(items) {
                history in
                NavigationLink(destination: HistoryDetail(history: history)) {
                    CategoryItem(history: history)
                
            }
        }
        }
        .buttonStyle(PlainButtonStyle())
        .padding()
    }
}

struct Cate_Previews: PreviewProvider {
    static var previews: some View {
        Cate()
            .environmentObject(ModelData())
    }
}
