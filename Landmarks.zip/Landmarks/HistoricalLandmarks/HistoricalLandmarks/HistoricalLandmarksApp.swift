//
//  HistoricalLandmarksApp.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/06.
//

import SwiftUI

@main
struct HistoricalLandmarksApp: App {
    @StateObject private var modelData = ModelData()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(modelData)
        }
    }
}
